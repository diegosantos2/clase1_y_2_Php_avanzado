<?php

// POO Avanzada


// !!! Cuando yo generalizo, creo una categoría en donde sus miembros son intercambiables entre sí.
// !!! Con las clases generalizo objetos. Con los abstractos, generalizo las clases.


// Abstractos (s.o.L.I.D)
// * Todo aquello que NO pueda generar un objeto directamente (NO new, NO son objetos)
// * Herramientas que NO gestionan objetos
// * Generalización de clases. Hacen las CLASES intercambiables

//// Herramientas
// Interfaces           ===> NO modifican el tipo 
// Clases abstractas    ===> Modifican el tipo


// Concretos 
// * Todo aquello que pueda generar un objeto directamente (new, o son objetos)
// * Herramientas que gestionan objetos
// * Acceso directo a los datos funcionales de la app

//// Herramientas
// valores directos ===> CONCRETO <
// objetos          ===> CONCRETO <<
// clases           ===> CONCRETO <<<

abstract class Entidad
{}

interface IEntidad
{
    public function getAll();
}

abstract class Producto extends Entidad implements IEntidad
{
    public $id;
    public $nombre;
    public $precio;

    public abstract function getAll();
}

new IEntidad();

/*

$obj = new Producto();
$obj->id = 10;
$obj->nombre = "Celular";
$obj->precio = 2500;


// Generalización

// #1
function mostrarNumeroAumentado(int $numero)
{
    echo $numero + 4;
}


// #2
$carlos = [
    'id' => 1,
    'nombre' => 'Carlos'
];

$alberto = [
    'id' => 2,
    'nombre' => 'Alberto'
];

$juana = [
    'id' => 3,
    'nombre' => 'Juana'
];

// Generalización de objetos
class Cliente
{
    public $id;
    public $nombre;
}

function mostrarCliente(Cliente $cli)
{
    var_dump($cli->nombre);
}
*/