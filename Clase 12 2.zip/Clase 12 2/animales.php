<?php

interface Jsonable
{
    public function json();
}

abstract class SerVivo
{}

abstract class Animal extends SerVivo
{}

abstract class Cuadrupedo extends Animal
{}

class Perro extends Cuadrupedo implements Jsonable, Countable
{
    public function json()
    {
        return json_encode($this);
    }

    public function count()
    {
        return 10;
    }
}

class Gato extends Cuadrupedo
{}

function toJson(Jsonable $jble)
{
    var_dump($jble->json());
}

$miGato = new Gato();
echo count($miGato);