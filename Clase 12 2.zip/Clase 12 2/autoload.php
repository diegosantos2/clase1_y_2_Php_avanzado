<?php

spl_autoload_register(function($notFoundClassName){
    $path = $notFoundClassName;

    $path = str_replace('\\', '/', $path);
    $path = strtolower(substr($path, 0, 1)) . substr($path, 1);

    if(file_exists("../$path.php"))
        require_once "../$path.php";
    else if(file_exists("../vendor/$path.php"))
        require_once "../vendor/$path.php";
});
