<?php

// mi app final

/*
*/
require_once 'Facturacion/IFilaFactura.php';
require_once 'Facturacion/Factura.php';

class ProductoUnicoFilaFactura implements IFilaFactura
{
    private $id;
    private $nombre;
    private $precio_unitario;
    private $cantidad;

    public function __construct(
        $id,
        $nombre,
        $precio_unitario,
        $cantidad
    ) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->precio_unitario = $precio_unitario;
        $this->cantidad = $cantidad;
    }

    public function getTotal()
    {
        return $this->precio_unitario * $this->cantidad;
    }
}

class PetroleoFilaFactura implements IFilaFactura
{
    public $cod_proveedor;
    public $tasa;
    public $base;
    public $litros;

    public function __construct(
        $cod_proveedor,
        $tasa,
        $base,
        $litros
    )
    {
        $this->cod_proveedor = $cod_proveedor;
        $this->tasa = $tasa;
        $this->base = $base;
        $this->litros = $litros;
    }

    public function getTotal()
    {
        return $this->tasa * $this->base * $this->litros;
    }
}

class NuevaFila implements IFilaFactura {}

$factura = new Factura();

$factura->addField(new ProductoUnicoFilaFactura(1, "Celular", 2500, 1));
$factura->addField(new ProductoUnicoFilaFactura(2, "Teclado", 2000, 1));
$factura->addField(new PetroleoFilaFactura(1002, 0.5, 2500, 1000));
$factura->addField(new ProductoUnicoFilaFactura(3, "Memoria RAM", 3000, 2));

echo "El total de la factura es: ".$factura->total();


/*
require_once 'Articulos/Articulo.php';
require_once 'Articulos/CRUDArticulo.php';

class Producto extends Articulo
{
    public $peso;

    public function __construct($id, $nombre, $peso)
    {
        parent::__construct($id, $nombre);
        $this->peso = $peso;
    }
}

$crud = new CRUDArticulo();

$crud->create(new Producto(1, "Producto A", 45));
*/