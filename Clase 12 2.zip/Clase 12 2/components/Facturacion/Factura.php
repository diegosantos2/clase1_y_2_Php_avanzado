<?php

class Factura
{
    private $fields = [];

    public function addField(IFilaFactura $field)
    {
        array_push($this->fields, $field);
        return $this;
    }

    public function total()
    {
        return array_reduce($this->fields, function($total, $field){
            return $total + $field->getTotal();
        });
    }
}
