<?php

interface IFilaFactura
{
    public function getTotal();
}