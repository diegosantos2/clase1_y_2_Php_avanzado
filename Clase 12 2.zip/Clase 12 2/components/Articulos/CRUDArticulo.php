<?php

class CRUDArticulo
{
    public function create(Articulo $articulo)
    {
        echo "Creando en la base de datos el articulo con ID ".$articulo->id."\n";
        var_dump($articulo);
    }
}