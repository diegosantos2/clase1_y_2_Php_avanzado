<?php

namespace App\Entities;

// Plain Old (Php) Object
class Producto
{
    public $id;
    public $foto;
    public $titulo;
    public $descripcion;

    public function json()
    {
        return json_encode($this);
    }
}
