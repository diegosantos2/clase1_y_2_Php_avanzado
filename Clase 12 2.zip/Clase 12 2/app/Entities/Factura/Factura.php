<?php

class Factura
{
    private $fecha;
    private $detalle = []; // FacturaDetalle
}
