<?php

class FacturaDetalle
{
    
}