<?php

namespace App\Entities\Carrito;

class Carrito
{

}
