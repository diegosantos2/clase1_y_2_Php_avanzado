<?php

class Cotizacion
{
    private $fecha;
    private $valor;
}
