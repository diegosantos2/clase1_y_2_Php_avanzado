<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!-- SEO -->
		<!-- Fin SEO -->
		<title>Showroom || Anteojos</title>
		<!-- Estilos CSS -->
		<link rel="stylesheet" href="/css/globals.css" />
		<link rel="stylesheet" href="/css/detalle.page.css" />
	</head>
	<body>
		<header>
			<a href="#" id="logo">Showroom</a>
			<div id="siteMap">
				<a href="index.html" class="backLink">Home /</a>
				<a href="categoria.html" class="backLink">Anteojos /</a>
				<a href="#" class="backLink" style="color: black"
					>Anteojos redondeados
				</a>
			</div>
		</header>

		<main>
			<h1>Anteojos redondeados</h1>

			<div id="contenido">
				<div id="texto">
					Lorem ipsum dolor sit amet consectetur adipisicing elit.
					Laboriosam magnam deserunt, dicta vel itaque, illum libero
					labore aperiam ratione veniam, consequuntur neque. Omnis
					neque ab eaque quo. Sed, vitae beatae! Dolor rerum cum
					dolorem dignissimos sequi eum, exercitationem quas
					laudantium doloremque omnis quos nisi facilis voluptatibus
					architecto odit doloribus necessitatibus repellendus minus,
					ratione excepturi adipisci. Fugiat porro voluptate corporis
					magni. Reprehenderit quia harum fuga sapiente? Doloribus
					temporibus earum laborum asperiores dicta, eveniet dolore
					dolorem ducimus quis a voluptates eius quidem ipsa totam
					voluptatibus autem labore non obcaecati cumque rerum facere?
					Nam cumque odit, reiciendis dolores ut recusandae itaque
					odio. Quasi corporis eaque aliquid ab tenetur, ut, aut odit
					voluptas, sit fugiat magnam commodi laborum! Impedit beatae
					perspiciatis numquam non? Enim? Sequi, corporis sint ducimus
					suscipit minima aperiam alias reiciendis vero, excepturi
					consequuntur vitae cum eius. Odio soluta dolorem omnis
					atque, provident, maxime debitis adipisci molestias pariatur
					reprehenderit voluptatum, quo obcaecati? Sint, vero
					expedita? Cumque cum quisquam itaque quasi? Delectus,
					recusandae maxime vero deleniti molestias corporis amet
					sapiente aliquid doloremque dolorem assumenda, similique
					nihil voluptates veniam totam temporibus culpa, architecto
					sed? Quasi, porro hic praesentium et sunt obcaecati
					repellendus molestias rem suscipit aut vitae dicta mollitia
					inventore vel error, voluptatem animi repudiandae illo
					autem! Provident expedita laborum veniam commodi ipsam
					dicta! Ullam cum nam aliquam sint temporibus iure debitis!
					Voluptates placeat, sequi fuga amet ipsam, exercitationem
					voluptate omnis magnam alias, esse optio. Sed aspernatur
					commodi, harum vero repudiandae magni labore sequi! Atque id
					error fugit dolor maiores. Rem incidunt ipsa dolores a iste
					tempore ullam ab dolorem alias tenetur deserunt voluptate et
					numquam quisquam, facere cum natus, nulla quibusdam corrupti
					excepturi? Culpa, iste. Ratione ipsum fuga accusamus, omnis
					qui vel debitis numquam distinctio consequatur atque odit ut
					ullam sint culpa necessitatibus tenetur eum! Asperiores eos
					optio incidunt odit impedit ea iusto!
				</div>
				<div id="miniaturas">
					<div class="imagenes">
						<div
							class="imagen"
							id="img1"
							style="
								background-image: url(/img/Anteojos/ali-pazani-GwglcplmXDs-unsplash.jpg.webp);
							"
						></div>
					</div>

					<h1 class="relacionados_titulo">Productos relacionados</h1>

					<div class="relacionados">
							<a
								class="thumb"
								href="#img1"
								style="
									background-image: url(/img/Anteojos/ali-pazani-GwglcplmXDs-unsplash.jpg.webp);
								"
							></a>

							<a
							class="thumb"
							href="#img1"
							style="
								background-image: url(/img/Anteojos/ali-pazani-GwglcplmXDs-unsplash.jpg.webp);
							"
						></a>

						<a
						class="thumb"
						href="#img1"
						style="
							background-image: url(/img/Anteojos/ali-pazani-GwglcplmXDs-unsplash.jpg.webp);
						"
					></a>
					</div>

					<div id="acciones">
						<a href="http://www.facebook.com/sharer.php?u=LINK_AQUI" target="_blank">
							<img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" />
						</a>
						<a href="https://twitter.com/share?url=LINK_AQUI&amp;text=TEXTO&amp;hashtags=TAGS" target="_blank">
							<img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" />
						</a>
					</div>

				</div>
			</div>
		</main>
	</body>
</html>
