<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!-- SEO -->
		<!-- Fin SEO -->
		<title>Showroom || Anteojos</title>
		<!-- Estilos CSS -->
		<link rel="stylesheet" href="/css/globals.css" />
		<link rel="stylesheet" href="/css/categoria.page.css" />
	</head>
	<body>
		<header>
			<a href="#" id="logo">Showroom</a>
            <div id="siteMap">
				<div id="siteMap">
					<a href="index.html" class="backLink">Home /</a>
					<a href="#" class="backLink"  style="color: black;">Anteojos</a>
				</div>
            </div>
		</header>

		<main>
			<h1>Anteojos</h1>

			<div id="items">
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/ali-pazani-GwglcplmXDs-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/apostolos-vamvouras-mKi4QEJXRCs-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/charles-deluvio-1-nx1QR5dTE-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/chase-fade-WgjmiOxYKRQ-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/ethan-robertson-SYx3UCHZJlo-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/giorgio-trovato-K62u25Jk6vo-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/karsten-winegeart-zgLydtnQmS4-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/noah-black-1p3N5SHz0Hk-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/sebastian-coman-travel-dtOTQYmTEs0-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
				<div
					class="item"
					style="
						background-image: url(/img/Anteojos/stephanie-hau-P4TPjOXKqY8-unsplash.jpg.webp);
					"
				>
					<a href="detalle.html">Lorem Ipsum</a>
				</div>
			</div>
		</main>
	</body>
</html>
