<?php

namespace App\Repositories\Carrito;

use App\Entities\Carrito\Carrito;

class CarritoSessionRepository
{
    public function get(): Carrito
    {
        return $_SESSION['cart'];
    }

    public function set(Carrito $carrito)
    {
        $_SESSION['cart'] = $carrito;
    }
}
