<?php

namespace App\Controllers;

class HomeController
{
    public function Index($request)
    {
        require_once '../app/Views/home.php';
    }
}
