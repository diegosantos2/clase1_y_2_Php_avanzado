<?php

namespace App\Controllers;

class ProductoController
{
    public function Detalle($request)
    {
        require_once '../app/Views/producto.php';
    }
}
