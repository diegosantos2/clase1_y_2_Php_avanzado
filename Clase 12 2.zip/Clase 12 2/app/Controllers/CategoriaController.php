<?php

namespace App\Controllers;

class CategoriaController
{
    public function Detalle($request)
    {
        require_once '../app/Views/categoria.php';
    }
}
