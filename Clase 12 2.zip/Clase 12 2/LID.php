<?php

// L: sustitución de Liskov
//// Debo diseñar mi aplicación de tal forma que use las generalidades de cada categoría
//// Una estructura debe ser intercambiable por sus subtipos
//// Práctica: En la aplicación debemos usar los miembros más abstractos y genéricos posibles
//// Práctica: Usar los miembros abstractos siempre. Solo usar los concretos en caso que no pueda usarse los abstractos.

// D: inversión de Dependencias
//// Debes depender de abstractos, no de concretos.

// i: segregación de la Interfaz




interface IConVoz
{
    public function emitirSonido();
}

class Perro implements IConVoz 
{
    public function ladrar()
    {
        echo "Wow";
    }

    public function emitirSonido()
    {
        $this->ladrar();
    }
}

class Gato implements IConVoz 
{
    public function maullar()
    {
        echo "Meow";
    }

    public function emitirSonido()
    {
        $this->maullar();
    }
}

function app(IConVoz $conVoz) // para andar, necesita un ABSTRACTO
{
    $conVoz->emitirSonido();
}

app(
    new Gato()
);
