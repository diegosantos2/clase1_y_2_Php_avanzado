<?php

interface IProductosRepository
{
    public function getAll();
    public function getOne($id);
}

class ProductosMySqlRepository implements IProductosRepository
{
    public function getAll()
    {
        // Retorna un listado de todos los productos
    }

    public function getOne($id)
    {
        // Obtiene un solo producto
    }
}

class ProductosTestingRepository implements IProductosRepository
{
    public function getAll()
    {
        // Retorna un listado de todos los productos
    }

    public function getOne($id)
    {
        // Obtiene un solo producto
    }
}

/**
* Primera versión
*/
class HomePage
{
    private $productosRepository;

    public function __construct()
    {
        $this->productosRepository = ServiceContainer::get(IProductoRepository::class);
    }
}

/**
 * Completa
 */
class ProductPage
{
    public function __construct(IProductosRepository $productosRepository)
    {
        $this->productosRepository = $productosRepository;
    }
}




// En la app


$productosRepository = new ProductosMySqlRepository();

class ServiceContainer
{
    private static $entries = [];

    /*
    Dado un abstracto, retornar su concreto
    */
    public static function get($abstract)
    {
        return ServiceContainer::$entries[$abstract];
    }

    /*
    Asignar un concreto a un abstracto
    */
    public static function set($abstract, $concrete)
    {
        ServiceContainer::$entries[$abstract] = $concrete();
    }
}

ServiceContainer::set(IDataSource::class, function(){
    return new MySqlDataSource();
});

ServiceContainer::set(IProductoRepository::class, function(){
    echo "Creando ProductoMySqlRepository";
    return new ProductoMySqlRepository(
        ServiceContainer::get(IDataSource::class)
    );
});

$page = new HomePage(ServiceContainer::get(IProductoRepository::class));
