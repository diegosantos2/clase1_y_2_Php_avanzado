<?php
/*
/Estrucutras de datos
/Lógica de los casos de uso
/...
/..
/..
*/

// Estrucuta de Datos
class Producto
{
    public $id;
    public $nombre;
}

class ProductoRepository // Adapter
{
    public function findAll()
    {}
}

interface IAuthenticable
{
    public function getWhiteList();
}


// Una alternativa
/*
class AuthService
{
    public function executeUseCase(IAuthenticable $useCase)
    {

    }
}
*/
/*
abstract class Authenticable {
    public $allowed = [];

    public function metodo()
    {
        // ...
    }
}
*/
// Casos de Uso
class ObtenerTodosProductos extends Authenticable
{

    public function execute()
    {

    }
/*
    public function getWhiteList()
    {
        return [
            'guest',
            'sales'
        ];
    }
    */
}
