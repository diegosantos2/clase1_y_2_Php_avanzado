<?php

require_once '../autoload.php';

use Http\Server;

$server = new Server();

$server->useSessionStart();

$server->useMvcRouter('App\\Controllers', 'Home', 'Index');

$server->handle();
